Solicitud de URL
https://sica.sunagro.gob.ve/despachos/registrar
Método de solicitud
GET
Código de estado
200 OK
Dirección remota
190.205.103.97:443
Política del referente
strict-origin-when-cross-origin

ENCABEZADOS DE RESPUESTA
cache-control
max-age=0, must-revalidate, no-cache, no-store, private
connection
Keep-Alive
content-encoding
gzip
content-length
20453
content-type
text/html; charset=UTF-8
date
Fri, 15 Aug 2025 16:12:07 GMT
expires
Mon, 01 Jan 1990 00:00:00 GMT
keep-alive
timeout=10, max=300
pragma
no-cache
server
Apache
set-cookie
XSRF-TOKEN=eyJpdiI6IkxnKzFGUStTMEJRN3JvWTBUVzJyWFE9PSIsInZhbHVlIjoiVUlNTzFqREczSzBQY2VRMndtNm9NN1NzcS9iRDFzQTVpNzFOQnY1b2V4MVpkaXoxR1hTZ2FJSllmblVrenJmZTRDdWNlMmRNRUNrSlNlVjJEbDFBb2hsbmg1UTd4VWdkWGtScnA0VFpPMFpHWUpGWVE2cndKZ2FWcEpBaWdLTjQiLCJtYWMiOiIxZDdmM2QyNGVkZDBhZTZlYWMwMThlYjg3NDlmNWMzYjMyNDkwOTNkYWU4ZDlmZDQwODJjODBjODllYTI5ZjI3IiwidGFnIjoiIn0%3D; expires=Fri, 15 Aug 2025 16:22:07 GMT; Max-Age=600; path=/; secure; samesite=lax;HttpOnly;Secure
set-cookie
148fa94fa6a5c4f33eas3432bde9a7bff5c1a2570b90afb0b0b2f29852b9=eyJpdiI6ImsyOWtvdDcxKzNNMHRFVUJvQ0JCRFE9PSIsInZhbHVlIjoiZnNzamVybmxmaldZWUx6UnU4YkkxMS93UkdJQUNwQzJxcFhNNEVPdld6NVNsREYvNDMvVkxlOFRVRDJlLzB4RStEUmdEWDJGcWhzSnM0Q2xKNFB3Q1JJd3VIS0h2SFB1SitPVjhSUEV1czd3RlhpOHZjbEkrYlFUZUJldkdGR2ciLCJtYWMiOiIyNjk0YzNhZTg5NzE2MDcxZDcwZTkwODA2NGRkZGMzOTJjMWFhZDc3YjJiOWQ5N2Q5NmY1ZmFiZTlmN2JkNDg1IiwidGFnIjoiIn0%3D; path=/; secure; httponly; samesite=lax;HttpOnly;Secure
vary
Accept-Encoding
x-content-type-options
nosniff
x-frame-options
SAMEORIGIN
x-frame-options
SAMEORIGIN
x-xss-protection
1; mode=block


ENCABEZADOS DE LA SOLICITUD
accept
text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
accept-encoding
gzip, deflate, br, zstd
accept-language
es-US,es;q=0.9,es-419;q=0.8,en;q=0.7,gl;q=0.6,la;q=0.5,fr;q=0.4
cache-control
no-cache
connection
keep-alive
cookie
3c234b41a96dc1291ad149e71734eba388a31a59=eyJpdiI6Inl6UjlodFlZSkFhRXZxTHI2bjRhOWc9PSIsInZhbHVlIjoidldoWkZpaUlZemtlSUQ4NG9DK1kwa1ZGWGl2ampXOHI0OExRYXR1bmxodTFKbGlnUnpoMlhuaS9PMmg5MzVHVEpuV0RqZjVsbmhVdDM4UWxUb21HWFpGUWZyZ2dmT1hhaS92UE96ZERyK3FvUHhTRkl1U0VvTUFIdHBGSnhKQjdqM2pKdVQrUk1HZS9RTXY0ZkdJd1p3PT0iLCJtYWMiOiIzNzI2NGQyODM1MjRhNjA2YTc1ZWJlNWM0ZDVhMzRjOWQwZjM0NjUwZmI0OWEwNGJhNjJlZTNlZmU4NjI4MjY3IiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IkttM2k0R1M3bGthWm5zeFB1UVZobVE9PSIsInZhbHVlIjoiRXdTVDFPUEJsSnJibE51NmJYVkYyQVA3Rm54QVJoZkRKTURUQ1FLVXFmcFBLV1djYmV6bGlHVTRMdHFFYXNHT1NpS3VpWklvRWNjMEtKL3BhUWw1bnZicGhkdGhBcDN6cDBZRWpMc1o3R1NYLzY3U1M3WDQySjhRbnpYQlE0MzYiLCJtYWMiOiJjZTBmZWU0MWQ2NGVjMjBkYzAwYTM5YWY1NTZhMmM5M2I1NmZkYjNjZGZkOTE0YTc1OWEwNjRjMjRmNDA3OTY5IiwidGFnIjoiIn0%3D; 148fa94fa6a5c4f33eas3432bde9a7bff5c1a2570b90afb0b0b2f29852b9=eyJpdiI6Inh1T1NaUUQ2UVlTRG9tWkNUaFZMMUE9PSIsInZhbHVlIjoiY1B1SVJWWFdGZVlvbURueEpJeGNtWmtXMSs1RExiOHNITkFBbWloaHpYVjdoQWpxL293L1pjKzdiZ0tQU1VoeE1VT1ROUEtTdysvOHpzaVdvZ0pCb09LT0JNU0QxMmlRRFExZnJzeVRFZkJadTVRMDZWaWtNcGFLS001NlZIRVYiLCJtYWMiOiJhZDk1NjAyMWUzNDc2MjU1YmY3ODEwMmI4NzljMWM4ZThkNzkxMmZlNDk2YmFkZTY5ZDdmY2EyODM2NDM0ZGI4IiwidGFnIjoiIn0%3D
host
sica.sunagro.gob.ve
pragma
no-cache
referer
https://sica.sunagro.gob.ve/despachos
sec-ch-ua
"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"
sec-ch-ua-mobile
?0
sec-ch-ua-platform
"macOS"
sec-fetch-dest
document
sec-fetch-mode
navigate
sec-fetch-site
same-origin
sec-fetch-user
?1
upgrade-insecure-requests
1
user-agent
Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36


RESPUESTA
----------


<!DOCTYPE html>
<html lang="es">
<head>
            <!-- NO JAVASCRIPT -->
        <noscript>
            <meta http-equiv="refresh" content="0;url=https://sica.sunagro.gob.ve/dependencias">
        </noscript>
    
    <meta charset="utf-8">
    <!-- RESPONSIVO -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CANONICAL -->
    <link rel="canonical" href="https://sica.sunagro.gob.ve/login">

    <!-- DESCRIPTION -->
    <meta name="description" content="Ejecutar las políticas públicas relacionadas con el Sistema Nacional Integral Agroalimentario (SNIA), dictadas por el Ejecutivo Nacional, con objeto de garantizar la distribución justa y equitativa en materia de producción e importación de productos agroalimentarios en coordinación con los entes u órganos competentes, así como, asegurar la disponibilidad y acceso oportuno de alimentos inocuos, de calidad y cantidad suficiente a la población y al mercado nacional, contribuyendo con la seguridad y soberanía agroalimentaria del país.">

    <!-- KEYWORDS -->
    <meta name="Keywords" content="sunagro, Sistema Nacional Integral Agroalimentario, "/>
    <meta name="theme-color" content="#4285f4" />

    <!-- CSRF TOKEN -->
    <meta name="csrf-token" content="knq0xe7x2pfCI8oSyVANu5P8zYlw5XY8auFFf27w">

    <title>Sunagro</title>

    <!-- WHATSAPP -->
    <meta property="og:image" content="https://sica.sunagro.gob.ve/img/sunagro_icon.webp"/>
    <meta property="og:image:secure_url" content="https://sica.sunagro.gob.ve/img/sunagro_icon.webp"/>
    <meta property="og:image:type" content="image/png" />
    <meta property="og:image:width" content="300"/>
    <meta property="og:image:height" content="300"/>
    
    <link rel="shortcut icon" type="image/x-icon" href="https://sica.sunagro.gob.ve/favicon.ico">

    <link href="https://sica.sunagro.gob.ve/css/sunagro-styles.min.css?v=1.0.4" rel="stylesheet" type="text/css">
    <link href="https://sica.sunagro.gob.ve/css/styles.css?v=1.0.4" rel="stylesheet" type="text/css">

        <style >[wire\:loading], [wire\:loading\.delay], [wire\:loading\.inline-block], [wire\:loading\.inline], [wire\:loading\.block], [wire\:loading\.flex], [wire\:loading\.table], [wire\:loading\.grid], [wire\:loading\.inline-flex] {display: none;}[wire\:loading\.delay\.shortest], [wire\:loading\.delay\.shorter], [wire\:loading\.delay\.short], [wire\:loading\.delay\.long], [wire\:loading\.delay\.longer], [wire\:loading\.delay\.longest] {display:none;}[wire\:offline] {display: none;}[wire\:dirty]:not(textarea):not(input):not(select) {display: none;}input:-webkit-autofill, select:-webkit-autofill, textarea:-webkit-autofill {animation-duration: 50000s;animation-name: livewireautofill;}@keyframes livewireautofill { from {} }</style>
    <script src="/vendor/livewire/livewire.js?id=90730a3b0e7144480175&v=1.0.4" data-turbo-eval="false" data-turbolinks-eval="false" ></script><script data-turbo-eval="false" data-turbolinks-eval="false" >window.livewire = new Livewire();window.Livewire = window.livewire;window.livewire_app_url = '';window.livewire_token = 'knq0xe7x2pfCI8oSyVANu5P8zYlw5XY8auFFf27w';window.deferLoadingAlpine = function (callback) {window.addEventListener('livewire:load', function () {callback();});};let started = false;window.addEventListener('alpine:initializing', function () {if (! started) {window.livewire.start();started = true;}});document.addEventListener("DOMContentLoaded", function () {if (! started) {window.livewire.start();started = true;}});</script>

    <script src="https://sica.sunagro.gob.ve/js/vendor.bundle.base.js?v=1.0.4" type="text/javascript"></script>
</head>

<body class="sidebar-dark ">
    <div class="container-scroller">
        <nav wire:id="SSE3sPkDLSdaqAzqTb4P" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;SSE3sPkDLSdaqAzqTb4P&quot;,&quot;name&quot;:&quot;eyJpdiI6IkhSNmN6YnBoUnVKRmtBcU1ZeVJScmc9PSIsInZhbHVlIjoiMUxmOGV3ZmwvRkJpYkgxQkRyYTlUdXM3RzBaYXVtODQ5c1I4YUx5RjMxaz0iLCJtYWMiOiIzYTdiY2M2YzJiODllZDdjNTk1MzgxMzFmZDYwYTJjOTU0MmJkY2M2YzY5ZDBiYmVmMDdiNzkyMzExZTU1ZDVlIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;SG5KZmVsTTNTUHNjRUNickoxVHVpL3NnbVpDTm1GMTNLcExCOXZMTWVwTT0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:{&quot;l4241256140-0&quot;:{&quot;id&quot;:&quot;ubKLY4UHDBcFQKqKSHgA&quot;,&quot;tag&quot;:&quot;li&quot;},&quot;l4241256140-1&quot;:{&quot;id&quot;:&quot;LSqy2MOlKyUE0APoPcrj&quot;,&quot;tag&quot;:&quot;div&quot;}},&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;9a939328&quot;,&quot;data&quot;:[],&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;3a1b7fc03cf6cd360bb233ba5d1142adc56873129389ce8aa822e5c4a1542682&quot;}}" class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="https://sica.sunagro.gob.ve"><img
                src="https://sica.sunagro.gob.ve/img/sunagro_logo.png" alt="logo" /></a>
        <a class="navbar-brand brand-logo-mini" href="https://sica.sunagro.gob.ve"><img
                src="https://sica.sunagro.gob.ve/img/sunagro_icon.webp" alt="logo" /></a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize"
            wire:click="$emit('emg3RGdzaXNac0ptQlU3ZURHNnJzbU5vVW1tWXJ6UEwxbjd4VWdReXZORT0%3D', 'emg3RGdzaXNac0ptQlU3ZURHNnJzbU5vVW1tWXJ6UEwxbjd4VWdReXZORT0%3D')">
            <span class="mdi mdi-menu"></span>
        </button>
        <img src="https://sica.sunagro.gob.ve/img/sunagro_cintillo2.png" alt="" width="53%" class="d-block d-md-none">

        <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item">
                <img src="https://sica.sunagro.gob.ve/img/sunagro_cintillo.png" alt="" width="93%" class="d-none d-md-block">
            </li>
            <li wire:id="ubKLY4UHDBcFQKqKSHgA" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;ubKLY4UHDBcFQKqKSHgA&quot;,&quot;name&quot;:&quot;eyJpdiI6Imw2cEJGRzFBZHI1WC94TU11NmpYU3c9PSIsInZhbHVlIjoiRGN2UGhQMG9QM3JJM2p2MFMydk8yN0VkSHUzYnpTYWx0eDVwNzc2OXZtUT0iLCJtYWMiOiJhMDI1ZTc4MWE5NzQ0MzczYTMxNTY5YzU0ZDgyYzlmOTJhOTcyODQyYTk4YmYyNjk5NzIxOGI5NTZlM2EyOGQwIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;2aa1afda&quot;,&quot;data&quot;:{&quot;data&quot;:[]},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;c42b04fbe7e583da578d102c7b24f7f03ea11ecfd8ee9816b6f031dc43c25283&quot;}}" class="nav-item dropdown mr-4" wire:ignore.self>
    <span class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center cursor-pointer" data-toggle="dropdown" wire:click="__method('R2NCTk9WWFhhNDRhYlcyQ1dRSGNEZz09')" wire:ignore.self>
                    <span class="notificacion-alert parpadeo"></span>
                <i class="mdi mdi-bell mx-0"></i>
    </span>
    <style>
        .dropdown-menu_ {
            width: 150px;
            height: 600px;
            overflow-y: auto;
        }
    </style>
    <div class="dropdown-menu dropdown-menu_ dropdown-menu-right navbar-dropdown preview-list"
        aria-labelledby="notificationDropdown" wire:ignore>
                    <p class="mb-0 font-weight-normal float-left dropdown-header">Notificaciones</p>
                            <a class="dropdown-item preview-item" href="https://sica.sunagro.gob.ve/despachos/en_transito">
                <div class="preview-thumbnail">
                    <div class="preview-icon bg-danger">
                        <i class="mdi mdi-information mx-0"></i>
                    </div>
                </div>
                <div class="preview-item-content">
                    <h6 class="preview-subject font-weight-normal">Guías vencidas</h6>
                </div>
            </a>
        
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164671455 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 18 minutos</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164668353 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 1 hora</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164667838 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 1 hora</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164660507 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 3 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia #164660326 va a tu destino</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    GANADERIA PUROLOMO C.A ha emitido una guia a tu destino <br>
                    <small>Una vez la recibas no olvides recibirla en el sistema - hace 3 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164654613 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 15 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164654414 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 15 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164654401 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 15 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164654392 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 15 horas</small>
                </p>
            </div>
        </a>
                <a class="dropdown-item preview-item" href="#">
            <div class="preview-thumbnail">
                <div class="preview-icon bg-info">
                    <i class="fas fa-bolt mx-0"></i>
                </div>
            </div>
            <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal">Guia generada exitosamente</h6>
                <p class="font-weight-light small-text mb-0 text-muted">
                    Guia #164654381 está con estatus: Aprobado <br>
                    <small>Una vez sea recibida por el destino se te notificará - hace 15 horas</small>
                </p>
            </div>
        </a>
            </div>
</li>

<!-- Livewire Component wire-end:ubKLY4UHDBcFQKqKSHgA -->            <li class="nav-item nav-profile dropdown mr-0 mr-sm-2">
                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                    <img src="https://sica.sunagro.gob.ve/img/avatar.png" alt="profile" />
                    <span class="nav-profile-name">CBULLON</span>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                    <a class="dropdown-item" href="https://sica.sunagro.gob.ve/logout"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="mdi mdi-logout text-primary"></i>
                        Salir
                    </a>
                    <form id="logout-form" action="https://sica.sunagro.gob.ve/logout" method="POST" class="d-none">
                        <input type="hidden" name="_token" value="knq0xe7x2pfCI8oSyVANu5P8zYlw5XY8auFFf27w" autocomplete="off">                    </form>
                </div>
            </li>
            <li class="nav-item nav-settings d-none d-lg-flex">
                <span class="mause-click" title="Ayuda">
                  <i class="mdi mdi-help-circle-outline"></i>
                </span>
            </li>
            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                <span class="mdi mdi-menu"></span>
              </button>
        </ul>
    </div>

    <div id="right-sidebar" class="settings-panel">
        <i class="settings-close mdi mdi-close"></i>
        <ul class="nav nav-tabs" id="setting-panel" role="tablist">
            <li class="nav-item">
                <a class="nav-link active cursor-pointer" title="" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">
                    SOLICITAR AYUDA&nbsp; <i class="icon-sidebar mdi mdi-help-circle-outline"></i>
                </a>
            </li>
        </ul>
        <div class="tab-content" id="setting-content">
            <div class="tab-pane fade show active scroll-wrapper" id="manuales-section" role="tabpanel" aria-labelledby="manuales-section">
                <div wire:id="LSqy2MOlKyUE0APoPcrj" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;LSqy2MOlKyUE0APoPcrj&quot;,&quot;name&quot;:&quot;eyJpdiI6IjN0S0VkM1NCUVJ1OVdtSXN2VjlVMlE9PSIsInZhbHVlIjoidzlORS9Cc1pNdC9ZWlFaSWJHVTJtdHlmYUVkanJmOFR1M1pUZEd0Yis2ST0iLCJtYWMiOiJmY2ExYjczODMwYWU0NTJhZTVmMmM2NmZjMTk2MGExNzJiYzAxNWVjZGEwMTQyYWY0YzAwYzMzODExYWRmMDc5IiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;aece92cb&quot;,&quot;data&quot;:{&quot;imagen&quot;:null,&quot;data&quot;:{&quot;UGVHNTVWbDR1RmQzWldTMG4wcHZrQT09&quot;:&quot;&quot;,&quot;RVpSdXdablJXaTAzQ3M3eVRScDdxdz09&quot;:&quot;&quot;,&quot;SHppc29PMFk4cmRKZWkwS2xkelpNZz09&quot;:&quot;&quot;}},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;ea644de6aa0309d4720a74d630f9cbd7bf67a5a1f88a23741e309190f77deb4d&quot;}}" class="px-3 componentModalAyuda">
    <div class="form-group px-3">
        <label for="exampleTextarea1">ASUNTO</label>
        <br>
        <small class="text-muted">
            Describa su problema o solicitud de ayuda
        </small>
        <textarea class="form-control" wire:model.defer="data.UGVHNTVWbDR1RmQzWldTMG4wcHZrQT09" id="data.UGVHNTVWbDR1RmQzWldTMG4wcHZrQT09"
        name="data.UGVHNTVWbDR1RmQzWldTMG4wcHZrQT09" rows="6"></textarea>
        <div class="d-flex flex-column">
    
                    
</div>
    </div>

    <div class="col-12 mt-2"         >
    <div class="form-group ">
                    <label class="form-label" for="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09">
                CELULAR
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$" name="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09" type="text"
            class="form-control form-control-md  "
            id="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09" autocomplete="off" title="El campo solo permite números."
            placeholder=" "
                         pattern="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$"                         data-inputmask-regex="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

    <div class="col-12 mt-2"         >
    <div class="form-group ">
                    <label class="form-label" for="data.SHppc29PMFk4cmRKZWkwS2xkelpNZz09">
                CORREO
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="" name="data.SHppc29PMFk4cmRKZWkwS2xkelpNZz09" type="email"
            class="form-control form-control-md  "
            id="data.SHppc29PMFk4cmRKZWkwS2xkelpNZz09" autocomplete="off" title="El campo solo permite una dirección de correo."
            placeholder=" "
                                                                                                                                     required              wire:model.defer="data.SHppc29PMFk4cmRKZWkwS2xkelpNZz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

    <div class="col-12 my-2">
        <label for="imagen">Capture(<small>Opcional</small>)</label>
        <input type="file" wire:model="imagen" id="imagen">
            </div>

    <button type="button" class="btn btn-sm btn-primary mr-2 pull-right" wire:click="__method('VldyM3NZT3ZFSGNHYzZyQ3dYRXNiQT09')" data-toggle="modal"
    data-target="#modal_tutoriales">ENVIAR</button>

    <a href="https://www.youtube.com/@sunagrooficial9064" target="_blank" class="btn btn-sm btn-primary mr-2 pull-right">VER TUTORIALES</a>
</div>


<!-- Livewire Component wire-end:LSqy2MOlKyUE0APoPcrj -->            </div>
        </div>
    </div>
</nav>

<!-- Livewire Component wire-end:SSE3sPkDLSdaqAzqTb4P -->
        <div class="container-fluid page-body-wrapper">
            <nav wire:id="iphxDW2UUAuuW5MHarhr" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;iphxDW2UUAuuW5MHarhr&quot;,&quot;name&quot;:&quot;eyJpdiI6IlNJSmNHc2IzTmdYQlpKTVY2T0NKRVE9PSIsInZhbHVlIjoibWJneS9LMy9UU1JGRVRySkJzdmIzWkYxQUhkN1lwL3krVlVaajBHRlFIZz0iLCJtYWMiOiJiN2Y0ODcwYTA3NDU5ODBhYTJlYzcxZjU1NGQxZDZmMTY1ZjdhMTAzNmQ5N2EwYjI0ZGYzOWNjYzVjYWI1OTNkIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;emg3RGdzaXNac0ptQlU3ZURHNnJzbU5vVW1tWXJ6UEwxbjd4VWdReXZORT0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;77089366&quot;,&quot;data&quot;:[],&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;9f74721a8bcd4a38b94ae3212ce7ba6aa064e25dafa29d992a9754739cfc1dcc&quot;}}" class="sidebar sidebar-offcanvas" id="" wire:ignore>
    <style>
        .sidebar .nav.sub-menu .nav-item::before {
            content: none;
        }

        .sidebar .nav.sub-menu {
            margin-bottom: 0;
            margin-top: 0;
            list-style: none;
            padding: 0.25rem 0 0 1.75rem;
        }
    </style>
    <ul class="nav">
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/home" >
                    <i class="icon-sidebar mdi mdi-home-outline menu-icon mr-1"></i>
                    <span class="menu-title">INICIO </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/inventario" >
                    <i class="icon-sidebar fas fa-adjust menu-icon mr-1"></i>
                    <span class="menu-title">INVENTARIO </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/despachos" >
                    <i class="icon-sidebar mdi mdi-truck-delivery menu-icon mr-1"></i>
                    <span class="menu-title">DESPACHO </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                     data-toggle="collapse" aria-expanded="false" aria-controls="recepcion"                      href="#recepcion" >
                    <i class="icon-sidebar mdi mdi-truck menu-icon mr-1"></i>
                    <span class="menu-title">RECEPCIÓN </span>
                                            <i class="menu-arrow"></i>
                                    </a>

                                    <div class="collapse" id="recepcion"><ul class="nav flex-column sub-menu"><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/despachos/recepcion"><i class="icon-sidebar mdi mdi-truck mr-1"></i>RECEPCIÓN DE GUIAS</a></li><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/recepcion/sin-guia"><i class="icon-sidebar fas fa-tty mr-1"></i>ANIMALES EN PIE</a></li><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/despachos/en_transito"><i class="icon-sidebar mdi mdi-truck-fast mr-1"></i>GUÍAS EN TRANSITO</a></li><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/recepcion/beneficio"><i class="icon-sidebar mdi mdi-truck mr-1"></i>RECEPCIÓN DE BENEFICIO</a></li></ul></div>                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/consumo" >
                    <i class="icon-sidebar mdi mdi-barley menu-icon mr-1"></i>
                    <span class="menu-title">CONSUMO </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/devoluciones" >
                    <i class="icon-sidebar fas fa-address-book menu-icon mr-1"></i>
                    <span class="menu-title">DEVOLUCIONES </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/produccion" >
                    <i class="icon-sidebar mdi mdi-home-silo menu-icon mr-1"></i>
                    <span class="menu-title">PRODUCCIÓN </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/multas" >
                    <i class="icon-sidebar mdi mdi-account-cancel menu-icon mr-1"></i>
                    <span class="menu-title">MULTAS </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/transferencias" >
                    <i class="icon-sidebar fab fa-accusoft menu-icon mr-1"></i>
                    <span class="menu-title">TRANSFERENCIAS RIF </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/deudas" >
                    <i class="icon-sidebar mdi mdi-account-cash menu-icon mr-1"></i>
                    <span class="menu-title">DEUDAS </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                                         href="https://sica.sunagro.gob.ve/tramites" >
                    <i class="icon-sidebar mdi mdi-account-cog menu-icon mr-1"></i>
                    <span class="menu-title">TRÁMITES </span>
                                    </a>

                            </li>
                    <li class="nav-item">
                <a class="nav-link "
                     data-toggle="collapse" aria-expanded="false" aria-controls="reportes-empresas"                      href="#reportes-empresas" >
                    <i class="icon-sidebar fa fa-list-alt menu-icon mr-1"></i>
                    <span class="menu-title">REPORTES </span>
                                            <i class="menu-arrow"></i>
                                    </a>

                                    <div class="collapse" id="reportes-empresas"><ul class="nav flex-column sub-menu"><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/reportes/transacciones"><i class="icon-sidebar fa fa-th-list mr-1"></i>HISTORIAL</a></li><li class="nav-item"><a class="nav-link  click" href="https://sica.sunagro.gob.ve/reportes/historial"><i class="icon-sidebar fas fa-clipboard-list mr-1"></i>TRANSACCIONES  </a></li></ul></div>                            </li>
            </ul>
</nav>

<!-- Livewire Component wire-end:iphxDW2UUAuuW5MHarhr -->            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
    <div class="col-md-12 grid-margin">
        <div class="card bg-white">
            <div class="card-body py-2 px-3 d-flex flex-column flex-md-row  justify-content-between" style="gap: 7px">
                <div class="d-flex flex-column flex-md-row" style="gap: 7px">
                    <small>
                        <span class='text-muted'>COD SICA:</span>
                        <strong>
                            700256
                        </strong>
                    </small>
                    <small>
                        <span class='text-muted'>RIF:</span>
                        <strong>
                            J-41248873-2
                        </strong>
                    </small>
                    <small>
                        <span class='text-muted'>TIPO DE ENTE:</span>
                        <strong>
                            ALMACENAMIENTO CONGELADO O FRIGORÍFICO
                        </strong>
                    </small>

                </div>


                <div class="d-none d-lg-flex flex-column flex-md-row" style="gap: 7px">
                    <small class="">
                        Viernes, 15 de Agosto del 2025, <span id="horaActual">12:12 PM</span>
                    </small>
                </div>
            </div>
            <div class="card-body py-2 px-3 d-flex flex-column flex-md-row  justify-content-between" style="gap: 7px">
                <div class="d-flex flex-column flex-md-row" style="gap: 7px">

                    <small>
                        <span class='text-muted'>RAZÓN SOCIAL:</span>
                        <strong>
                            INVERSIONES AJI C.A
                        </strong>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

                                            <div wire:id="sHMG2QtFIfB6w2F4jVnH" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;sHMG2QtFIfB6w2F4jVnH&quot;,&quot;name&quot;:&quot;eyJpdiI6ImVMR0QwQ29KMHhIRDIzWCtVRzY5cFE9PSIsInZhbHVlIjoiQWw3eXlDTDlSRUhEYnZ1NnkzY3VMQkExY243UXdyZ2VHNkx5THJiUkgzYz0iLCJtYWMiOiI2NTE4YTgxZjc2MDRkOWIyZDliNjgyYTFiZWJlZTdhMmMyZjM4MDZjN2IxYzU1YWY2M2Y1YWQ5MjA1NzU4ZDQ0IiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;LzN6OGVJbzFJNjBlSW5PRk9XOWVaQkMzNVZ0bGVrWmVzc3FlTmVnQzloVT0%3D&quot;,&quot;YTJnWEJUbmZ4UVR1NWtydHdXZWtGM1hxVGIwQ2xlTXVzNTlZcllCL0xVYz0%3D&quot;,&quot;WEJETUxiUG5Samhpa0loM09WSW1ONDhHZGxDNVdkR1FhVXNpNjFDZVJVYz0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:{&quot;l2055706833-0&quot;:{&quot;id&quot;:&quot;qG4q26u3eBNUCxNIgJeo&quot;,&quot;tag&quot;:&quot;div&quot;},&quot;l2055706833-1&quot;:{&quot;id&quot;:&quot;X4XSS1qF4Y9Gul3G0Zyu&quot;,&quot;tag&quot;:&quot;div&quot;}},&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;fd29f861&quot;,&quot;data&quot;:{&quot;data&quot;:{&quot;UERwY2ZvMm54ck1Hem9yWUwvZmJZdz09&quot;:&quot;&quot;,&quot;UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09&quot;:&quot;&quot;,&quot;QW5jemd4alB1WllDWjczbGFQaUpBUT09&quot;:&quot;&quot;,&quot;QjVzNkJoc216QUxDNVM0MzJVNDlRdz09&quot;:&quot;&quot;,&quot;SklYOFdOY082VFRjamE0TFJuNC9YZz09&quot;:&quot;&quot;,&quot;cWFjL1BPYjFSMHBuMWkxbi9PZ0dxdz09&quot;:&quot;&quot;,&quot;dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09&quot;:&quot;&quot;,&quot;MkNMdzRrM0JqeUUxUm1lWUJoNmFZQT09&quot;:&quot;&quot;,&quot;bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09&quot;:&quot;&quot;,&quot;dXFLNWlDbnRVelZPSTRBa2IyV2g4Zz09&quot;:&quot;&quot;,&quot;WHlvWDNuaFpuQ2lpN1lLOXV4OVgxUT09&quot;:&quot;&quot;,&quot;TDBiQUdSbFI2WXV6L051dGJtdlNudz09&quot;:1,&quot;THd2VHJ1QzNOWDVoUjlBRGZaSzIrZz09&quot;:&quot;&quot;,&quot;cW1YY01CcUNNRStMZDZoRzgvazJSdz09&quot;:false,&quot;U2ZqVERaeEE3SXZHenArWWNPZDNaQT09&quot;:&quot;&quot;,&quot;T1ZiK2RqbnZJS0tJd0t6ZXJNMjJlQT09&quot;:&quot;&quot;,&quot;YjFLVzREcHdXaURKZmk0YXpuS1FiZz09&quot;:&quot;&quot;,&quot;amhPaGg0c3k2YVUwa1RLN2VieFRvdz09&quot;:&quot;&quot;,&quot;cVhsY2ptSk1GRHc5Q1llaXM5Zittdz09&quot;:&quot;&quot;},&quot;empresas&quot;:[],&quot;conductores&quot;:[],&quot;vehiculos&quot;:[],&quot;rubros_&quot;:[],&quot;anios_cuspal&quot;:[&quot;2021&quot;,&quot;2022&quot;,&quot;2023&quot;,&quot;2024&quot;,&quot;2025&quot;],&quot;meses_cuspal&quot;:[&quot;Enero&quot;,&quot;Febrero&quot;,&quot;Marzo&quot;,&quot;Abril&quot;,&quot;Mayo&quot;,&quot;Junio&quot;,&quot;Julio&quot;,&quot;Agosto&quot;,&quot;Septiembre&quot;,&quot;Octubre&quot;,&quot;Noviembre&quot;,&quot;Diciembre&quot;]},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;579252a065f9bc7a7488120addf459432f3e59e93007c7a98831849ffe1e98bc&quot;}}" class="componentRegistro">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header text-center">
                    <h3>NUEVA GUÍA DE MOVILIZACIÓN</h3>
                </div>
                <div class="card-body">
                    <div class="card">
                        <div class="card-body p-0 m-1">
                            <div class="faq-section">
                                <div class="container-fluid bg-primary py-2 text-center">
                                    <h4 class="mb-0 text-white">DATOS DE LAS FACTURAS</h4>
                                </div>
                            </div>
                            <style>
                                /* Aplica estilos para los bordes blancos */
                                .table-bordered-white .table {
                                    border: 1px solid #fff !important;
                                }

                                /* Aplica estilos a las celdas con fondo blanco */
                                .table-bordered-white .table th,
                                .table-bordered-white .table td {
                                    background-color: #fff !important;
                                }

                                .table-white th,
                                .table-white td,
                                .table-white thead th,
                                .table-white tbody+tbody {
                                    border-color: #fff !important;
                                }
                            </style>
                            <table class="table table-bordered">
                                <tbody>
                                    <tr class="table-primary table-white">
                                        <td>
                                            Empresa Origen <small class="text-danger">*</small>:
                                        </td>
                                        <td>
                                            <strong>INVERSIONES AJI C.A</strong>
                                        </td>
                                        <td>
                                            Fecha Emisión:
                                        </td>
                                        <td>
                                            <strong>15-08-2025</strong>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="row">
                                <div class="col-12">
                                    <div class="alert alert-warning text-center mt-1" role="alert">
                                        <strong class="text-success" style="font-size: 34px;">1</strong>
                                        Indique el número de factura o documento que soporta el despacho.
                                    </div>

                                    <div class="form-group mt-1">
                                        <label class="" for="data.QjVzNkJoc216QUxDNVM0MzJVNDlRdz09">FACTURA(S) O DOCUMENTOS
                                            <small class="text-muted">Separe por comas si es más de una
                                                factura</small></label>
                                        <textarea type="text" wire:model.defer="data.QjVzNkJoc216QUxDNVM0MzJVNDlRdz09" id="data.QjVzNkJoc216QUxDNVM0MzJVNDlRdz09"
                                            name="data.QjVzNkJoc216QUxDNVM0MzJVNDlRdz09" class="form-control input-event" placeholder="FACTURA(S)"
                                            pattern="^[a-zA-Z0-9,.\s\-\_()\/#*]{3,270}$"
                                            data-inputmask-regex="^[a-zA-Z0-9,.\s\-\_()\/#*]{3,270}$"
                                            data-inputmask-placeholder=" "
                                            data-inputmask-showmaskonfocus="false" data-inputmask-showmaskonhover="false" required="" rows="4"></textarea>
                                        <div class="d-flex flex-column">
    
                    
</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body p-0 m-1">
                            <div class="faq-section">
                                <div class="container-fluid bg-primary py-2 text-center">
                                    <h4 class="mb-0 text-white">DATOS DE LA EMPRESA DESTINO</h4>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-lg-6 col-lx-6">
                                    <div x-data class="card">
                                        <div class="card-body px-1 m-1">
                                            <div class="alert alert-warning text-center" role="alert">
                                                <strong class="text-success" style="font-size: 34px;">2</strong> Ingrese
                                                el código SICA de la empresa y presione buscar.
                                            </div>
                                            <h4 class="card-title">CÓDIGO DE LA EMPRESA DESTINO</h4>
                                            <div class="add-items d-flex mt-4">
                                                <input x-mask="[0-9]{1,8}" type="text"
                                                    class="form-control todo-list-input input-event"
                                                    id="data.cWFjL1BPYjFSMHBuMWkxbi9PZ0dxdz09" name="data.cWFjL1BPYjFSMHBuMWkxbi9PZ0dxdz09"
                                                    autocomplete="off" title="Código" placeholder=" "
                                                    pattern="(?=.*[0-9]).{1,8}" data-inputmask-regex="[0-9]{1,8}"
                                                    data-inputmask-placeholder=" "
                                                    data-inputmask-showmaskonfocus="false"
                                                    data-inputmask-showmaskonhover="false" required=""
                                                    wire:model.defer="data.cWFjL1BPYjFSMHBuMWkxbi9PZ0dxdz09" im-insert="true">

                                                <button type="button" wire:loading.attr="disabled"
                                                    class="add btn btn-primary font-weight-bold todo-list-add-btn"
                                                    x-data="{ enabled: true }"
                                                    x-on:click="if (enabled) { enabled = false; $wire.searchEmpresaCodigo(); setTimeout(() => { enabled = true; }, 1000); }"
                                                    :disabled="!enabled">Buscar</button>
                                            </div>
                                            <div class="text-center">
                                                <div class="d-flex flex-column">
    
                    
</div>
                                            </div>

                                            <div x-data="{
                                                selectedCodigo: null,
                                                empresas: JSON.parse(JSON.stringify([])),
                                            }">
                                                <template x-if="!empresas.length">
                                                    <div class="text-center">
                                                        <h6 class="mb-1 text-muted">Escribe un código</h6>
                                                    </div>
                                                </template>
                                                <template x-if="empresas.length">
                                                    <div>
                                                        <template x-for="item in empresas" :key="item.id">
                                                            <div class="d-flex align-items-center py-1 border-bottom mt-1"
                                                                 style="cursor: pointer;"
                                                                 x-on:click="$wire.__method('LzN6OGVJbzFJNjBlSW5PRk9XOWVaQkMzNVZ0bGVrWmVzc3FlTmVnQzloVT0%3D', item.id);selectedCodigo=item.id"
                                                                 :class="{ 'alert-success': selectedCodigo === item.id }">
                                                                <div class="ml-3">
                                                                    <small x-text="item.razon_social + ' - ' + item.rif"></small>
                                                                </div>
                                                                <template x-if="selectedCodigo !== item.id">
                                                                    <i class="mdi mdi-circle-outline font-weight-bold ml-auto px-1 py-1 text-muted mdi-24px"></i>
                                                                </template>
                                                                <template x-if="selectedCodigo === item.id">
                                                                    <i class="mdi mdi-check-circle-outline font-weight-bold ml-auto px-1 py-1 text-success mdi-24px"></i>
                                                                </template>
                                                            </div>
                                                        </template>
                                                    </div>
                                                </template>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                                                    <div class="col-md-12 col-lg-6 col-lx-6">
                                        <div class="card" style="min-height: 300px">
                                            <div class="card-body d-flex justify-content-center align-items-center">
                                                <i class="fas fa-search text-muted fa-5x"></i>
                                            </div>
                                        </div>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                                        <div class="card">
                        <div class="card-body p-0 m-1">
                            <div class="faq-section mb-1">
                                <div class="container-fluid bg-primary py-2 text-center">
                                    <h4 class="mb-0 text-white">DATOS DEL TRANSPORTE</h4>
                                </div>
                            </div>

                            <div class="alert alert-warning text-center" role="alert">
                                <strong class="text-success" style="font-size: 34px;">3</strong> Ingrese la cédula del
                                conductor y la placa del vehículo.
                            </div>

                            <div wire:id="qG4q26u3eBNUCxNIgJeo" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;qG4q26u3eBNUCxNIgJeo&quot;,&quot;name&quot;:&quot;eyJpdiI6IjF5dnM1UXcrMlM3dk9qQ3FvVVBGbHc9PSIsInZhbHVlIjoiTWtkUWZucC9LUVlxK2U0QUpYV1FFRjN1bVY4bU5qTFQvZElwakVxNnZ1UT0iLCJtYWMiOiI4NDlhYjc4ZDc4YTExYmYwZDFlYzFiYTQ0NjJiNDIzODU2ZDdkNWI1Zjk5ZDI3OGY2MGZiNzRhMDMzODVjNTkyIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;5e1d8af8&quot;,&quot;data&quot;:{&quot;data&quot;:{&quot;UERwY2ZvMm54ck1Hem9yWUwvZmJZdz09&quot;:&quot;&quot;,&quot;dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09&quot;:&quot;&quot;,&quot;UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09&quot;:&quot;&quot;,&quot;TnZHZytBWG04R2RIUVUzdmQ3Sk52UT09&quot;:&quot;&quot;,&quot;RVpSdXdablJXaTAzQ3M3eVRScDdxdz09&quot;:&quot;&quot;,&quot;TDBiQUdSbFI2WXV6L051dGJtdlNudz09&quot;:1}},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;f5593df4ec1086e38bd85e29b9b71f4e0f5e54ef1dccbd093ebf9828a752a950&quot;}}" key='modalAddConductor' class="componentModalRegistroConductor">
    <div class="modal" id="addNuevoConductor" tabindex="-2" aria-hidden="false" wire:ignore.self>
    <div class="modal-dialog " wire:ignore.self>
        <div class="modal-content fade show" wire:ignore.self>
            <div class="modal-header bg-primary text-white p-2" wire:ignore.self>
                <h4 class="modal-title " id="exampleModalLabel"> NUEVO CONDUCTOR</h4>

                                    <button type="button" class="close close-modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                            </div>
            <div class="modal-body" wire:ignore.self>
                <form id="formPermission" class="row" wire:submit.prevent="__method('VWJlN2pYWHJkYm4wdXd0RVA3OGZlZz09')">
            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09">
                CÉDULA
                                    <small class="text-danger">*</small>
                                <small class="text-muted ">Ejemplo V-12345678</small>
            </label>
        
                
        <input x-mask="^[VJEGPvjegp]-\d{6,8}$" name="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09" type="text"
            class="form-control form-control-md  "
            id="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="^[VJEGPvjegp]-\d{6,8}$"                         data-inputmask-regex="^[VJEGPvjegp]-\d{6,8}$"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09">
                NOMBRE
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}" name="data.UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09" type="text"
            class="form-control form-control-md  "
            id="data.UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="(?=.*[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]).{3,150}"                         data-inputmask-regex="[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.UVEyRXZsaE9BMk9kUHZtVTd0cS85QT09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.TnZHZytBWG04R2RIUVUzdmQ3Sk52UT09">
                APELLIDO
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}" name="data.TnZHZytBWG04R2RIUVUzdmQ3Sk52UT09" type="text"
            class="form-control form-control-md  "
            id="data.TnZHZytBWG04R2RIUVUzdmQ3Sk52UT09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="(?=.*[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]).{3,150}"                         data-inputmask-regex="[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.TnZHZytBWG04R2RIUVUzdmQ3Sk52UT09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09">
                TELÉFONO
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$" name="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09" type="text"
            class="form-control form-control-md  "
            id="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$"                         data-inputmask-regex="^[0]{1}[4]{1}[12]{1}[246]{1}-[0-9]{7}$"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.RVpSdXdablJXaTAzQ3M3eVRScDdxdz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <!-- Permission table -->
            <div class="col-12 mt-75">
            </div>
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-primary mt-2 me-1">GUARDAR</button>
                <button type="reset" id="resetConductor" wire:click="__method('Z2xXSHVUN0xxbU14WnM5RVZVd1Zzdz09')"
                    class="btn btn-outline-secondary mt-2">
                    DESCARTAR
                </button>
            </div>
        </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#addNuevoConductor').on('click', '.close-modal', function() {
                $('#addNuevoConductor').modal('hide');
            });
        });
    </script>
</div>
    <script>
        // Función principal que aplica el inputmask y configura los eventos
        const addInputmask = (div) => {
            $(div).find('input').each(function() {
                $(this).inputmask();
                $(this).change((e) => {
                    window.livewire.find('qG4q26u3eBNUCxNIgJeo').set(e.target.id, e.target.value, !$(e.target).hasClass('lazy'));
                });
            });
        };

        // Ejecutar cuando el DOM esté listo
        $(document).ready(function() {
            $('.componentModalRegistroConductor').on('change', '.select2-events, .allcheck', function() {
                window.livewire.find('qG4q26u3eBNUCxNIgJeo').set($(this).attr('name'), $(this).val(), true);
            });

            window.livewire.find('qG4q26u3eBNUCxNIgJeo').on("YnpkZ0JOTlV0WjI0RzdnSFR3S2wzL3NnbVpDTm1GMTNLcExCOXZMTWVwTT0%3D", function() {
                $('#addNuevoConductor').modal('hide');
            });

            addInputmask(".componentModalRegistroConductor");
        });
    </script>
</div>

<!-- Livewire Component wire-end:qG4q26u3eBNUCxNIgJeo -->                            <div wire:id="X4XSS1qF4Y9Gul3G0Zyu" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;X4XSS1qF4Y9Gul3G0Zyu&quot;,&quot;name&quot;:&quot;eyJpdiI6IkxsYmx2SXR5VVZLdVp5MmMyQXZvOWc9PSIsInZhbHVlIjoiMmtMNnhEU1NCWmpHNVdpeXlKWENGSWhuMFNiZEJqMkNGS3FPbTYxSThKaz0iLCJtYWMiOiIyMWQzMmFjZmY0NDU0YmUxMzM3YjhiZTQ4NzhjNDIyNDFiZWRhZWViOGFmZTNhYjdjYzY2Y2I0MWM5YWI4OWE2IiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;88b62575&quot;,&quot;data&quot;:{&quot;data&quot;:{&quot;UERwY2ZvMm54ck1Hem9yWUwvZmJZdz09&quot;:&quot;&quot;,&quot;bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09&quot;:&quot;&quot;,&quot;WDhpKytlTlJGTjFtR2NqMjdpR0VCdz09&quot;:&quot;&quot;,&quot;RTlJSjhqeXJkU2hqYzRUYkhnZXdWdz09&quot;:&quot;&quot;,&quot;dWQxVkNEL1J1STEzcjYxU29RZngwRHc2WEg2TnA4YXpCczZLMkMvMzIyTT0%3D&quot;:&quot;&quot;,&quot;TDBiQUdSbFI2WXV6L051dGJtdlNudz09&quot;:1}},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;68a5d5edfda37a110821530ff341fdc9668968836a9e17af5f2f722b8223a2fb&quot;}}" key='modalAddVehiculo' class="componentModalRegistroVehiculo">
    <div class="modal" id="addNuevoVehiculo" tabindex="-2" aria-hidden="false" wire:ignore.self>
    <div class="modal-dialog " wire:ignore.self>
        <div class="modal-content fade show" wire:ignore.self>
            <div class="modal-header bg-primary text-white p-2" wire:ignore.self>
                <h4 class="modal-title " id="exampleModalLabel"> NUEVO VEHÍCULO</h4>

                                    <button type="button" class="close close-modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                            </div>
            <div class="modal-body" wire:ignore.self>
                <form id="formPermission" class="row" wire:submit.prevent="__method('VWJlN2pYWHJkYm4wdXd0RVA3OGZlZz09')">
            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09">
                PLACA
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="^[a-zA-Z0-9]{6,10}$" name="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09" type="text"
            class="form-control form-control-md  "
            id="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="^[a-zA-Z0-9]{6,10}$"                         data-inputmask-regex="^[a-zA-Z0-9]{6,10}$"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.RTlJSjhqeXJkU2hqYzRUYkhnZXdWdz09">
                MARCA
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}" name="data.RTlJSjhqeXJkU2hqYzRUYkhnZXdWdz09" type="text"
            class="form-control form-control-md  "
            id="data.RTlJSjhqeXJkU2hqYzRUYkhnZXdWdz09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="(?=.*[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]).{3,150}"                         data-inputmask-regex="[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.RTlJSjhqeXJkU2hqYzRUYkhnZXdWdz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12"         >
    <div class="form-group ">
                    <label class="form-label" for="data.WDhpKytlTlJGTjFtR2NqMjdpR0VCdz09">
                COLOR
                                    <small class="text-danger">*</small>
                                <small class="text-muted "></small>
            </label>
        
                
        <input x-mask="[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}" name="data.WDhpKytlTlJGTjFtR2NqMjdpR0VCdz09" type="text"
            class="form-control form-control-md  "
            id="data.WDhpKytlTlJGTjFtR2NqMjdpR0VCdz09" autocomplete="off" title="El campo solo permite letras y números."
            placeholder=" "
                         pattern="(?=.*[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]).{3,150}"                         data-inputmask-regex="[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ&amp;\s]{3,150}"
                            data-inputmask-placeholder=" "
                data-inputmask-showMaskOnFocus="false"
                data-inputmask-showMaskOnHover="false"
                                                                                                                     required              wire:model.defer="data.WDhpKytlTlJGTjFtR2NqMjdpR0VCdz09"              />
                    
        
                    <div class="d-flex flex-column">
    
                    
</div>



</div>


</div>

            <div class="col-12">
    <div class="form-group "  wire:ignore >
        
            <label class="form-label" for="data.dWQxVkNEL1J1STEzcjYxU29RZngwRHc2WEg2TnA4YXpCczZLMkMvMzIyTT0%3D">
                TIPO TRANSPORTE
                                <small class=" "></small>
            </label>
        
        <select wire:model.defer="data.dWQxVkNEL1J1STEzcjYxU29RZngwRHc2WEg2TnA4YXpCczZLMkMvMzIyTT0%3D" id="data.dWQxVkNEL1J1STEzcjYxU29RZngwRHc2WEg2TnA4YXpCczZLMkMvMzIyTT0%3D" name="data.dWQxVkNEL1J1STEzcjYxU29RZngwRHc2WEg2TnA4YXpCczZLMkMvMzIyTT0%3D"
            class="select2 select2-events select2-tipo-vehiculo"             >
            <option>SELECCIONE</option>
                                    <option value="NzVVczhFNTdRV1JVaWlkMHpURExNZz09">CAMION DE 15000 A 20000 KG</option>
                                    <option value="azZwbGtlQlV0MG1CUXBUNHd6VGptdz09">CAMIONES DE 5000 A 10000</option>
                                    <option value="dlcwbXJuaVZoa2tqT2p6YVVpa3ZsUT09">CAMION</option>
                                    <option value="SUtxT0NpWXRwSTFxQ3h0blRiQVQzZz09">GANDOLA</option>
                                    <option value="M01SSEQwODlUM2dZSlJXZkFxdnNjZz09">CAMION HASTA 5000 KG</option>
                                    <option value="NlJlWDVZV1ZaNmpHQ2xTOFZxL2U4dz09">CARRO PARTICULAR</option>
                                    <option value="QUk3Z1RiVHoreWtlclAxSTZIN2JtZz09">MOTO DE CARGA HASTA 1000 KG</option>
                                    <option value="OEp5SHR0NWUyVHVqMlZYN1ZmSG15QT09">CAMIONETA PICKUP</option>
        </select>
    </div>
    <div class="d-flex flex-column">
    
                    
</div>
</div>

            <!-- Permission table -->
            <div class="col-12 mt-75">
            </div>
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-primary mt-2 me-1">GUARDAR</button>
                <button type="reset" id="resetVehiculo" wire:click="__method('Z2xXSHVUN0xxbU14WnM5RVZVd1Zzdz09')"
                    class="btn btn-outline-secondary mt-2">
                    DESCARTAR
                </button>
            </div>
        </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#addNuevoVehiculo').on('click', '.close-modal', function() {
                $('#addNuevoVehiculo').modal('hide');
            });
        });
    </script>
</div>
    <script>
        $(document).ready(function() {
            const iconFormat = (icon) => {
                let originalOption = icon.element;
                if (!icon.id)
                    return icon.text;
                let aux = $(icon.element).data('icon');
                let $icon = (aux != '' ? '<i class="' + aux + '"></i>&nbsp;' : '') + icon.text;
                return $icon;
            }

            const addSelect2 = (select) => {
                select.wrap('<div class="position-relative"></div>');
                select.select2({
                    placeholder: ' ',
                    dropdownAutoWidth: true,
                    width: '100%',
                    dropdownParent: select.parent(),
                    templateResult: iconFormat,
                    templateSelection: iconFormat,
                    escapeMarkup: function (es) {
                        return es;
                    }
                });
            }

            const allSelect2 = () => {
                addSelect2($(".componentModalRegistroVehiculo .select2-tipo-vehiculo"));
            }; 

            const addInputmask = (div) => {
                $(div).find('input').each(function() {
                    $(this).inputmask();
                    $(this).change((e) => {
                        window.livewire.find('X4XSS1qF4Y9Gul3G0Zyu').set(e.target.id, e.target.value, !$(e.target).hasClass('lazy'));
                    });
                });
            }

            $('.componentModalRegistroVehiculo').on('change', '.select2-events, .allcheck ', function() {
                window.livewire.find('X4XSS1qF4Y9Gul3G0Zyu').set($(this).attr('name'), $(this).val(), true);
            });

            window.livewire.find('X4XSS1qF4Y9Gul3G0Zyu').on("RkI3WTAzVU9OTkplK2pjS1lIdHhQaXc1WWdqY0JxZm1iNlV5SXgwK1QvZz0%3D", function() {
                $('#addNuevoVehiculo').modal('hide');
                $('.componentModalRegistroVehiculo .select2-tipo-vehiculo').val("SELECCIONE").trigger('change');
            });
            addInputmask(".componentModalRegistroVehiculo");
            allSelect2();
        });
    </script>
</div>

<!-- Livewire Component wire-end:X4XSS1qF4Y9Gul3G0Zyu -->
                            <div class="row">
                                <div class="col-md-12 col-lg-6 col-lx-6">
                                    <div x-data class="card">
                                        <div class="card-body px-1 m-1">
                                            <h4 class="card-title mt-2">DATOS DEL CONDUCTOR</h4>
                                            <div class="add-items d-flex mt-4" wire:ignore>
                                                <input x-mask="^[VJEGPvjegp]-\d{6,8}$" type="text"
                                                    class="form-control todo-list-input input-event"
                                                    id="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09" name="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09"
                                                    autocomplete="off" title="Cédula" placeholder=" "
                                                    pattern="^[VJEGPvjegp]-\d{6,8}$"
                                                    data-inputmask-regex="^[VJEGPvjegp]-\d{6,8}$"
                                                    data-inputmask-placeholder=" "
                                                    data-inputmask-showmaskonfocus="false"
                                                    data-inputmask-showmaskonhover="false" required=""
                                                    wire:model.defer="data.dFZpVGlDZU1rK2xmOE5GYTB2UTF2dz09" im-insert="true">
                                                <button type="button" wire:loading.attr="disabled"
                                                    class="add btn btn-primary font-weight-bold todo-list-add-btn"
                                                    x-data="{ enabled: true }"
                                                    x-on:click="if (enabled) { enabled = false; $wire.searchConductorCedula(); setTimeout(() => { enabled = true; }, 1000); }"
                                                    :disabled="!enabled">Buscar</button>
                                            </div>
                                            <div class="text-center">
                                                <div class="d-flex flex-column">
    
                    
</div>
                                            </div>

                                            <div x-data="{
                                                selectedConductor: null,
                                                conductores: JSON.parse(JSON.stringify([])),
                                            }">
                                                <template x-if="!conductores.length">
                                                    <div class="text-center">
                                                        <h6 class="mb-1 text-muted">Escribe la cédula del conductor</h6>
                                                        <button type="button" class="btn btn-outline-info"
                                                            data-toggle="modal" data-target="#addNuevoConductor" wire:loading.attr="disabled">
                                                            Registrar Conductor <i class="fas fa-plus"></i>
                                                        </button>
                                                    </div>
                                                </template>
                                                <template x-if="conductores.length">
                                                    <div>
                                                        <template x-for="item in conductores" :key="item.id">
                                                            <div class="d-flex align-items-center py-1 border-bottom mt-1"
                                                                 style="cursor: pointer;"
                                                                 x-on:click="$wire.__method('YTJnWEJUbmZ4UVR1NWtydHdXZWtGM1hxVGIwQ2xlTXVzNTlZcllCL0xVYz0%3D', item.id);selectedConductor=item.id"
                                                                 :class="{ 'alert-success': selectedConductor === item.id }">
                                                                <div class="ml-3">
                                                                    <small x-text="item.nombre + ' ' + item.apellido + ' - ' + item.cedula"></small>
                                                                </div>
                                                                <template x-if="selectedConductor !== item.id">
                                                                    <i class="mdi mdi-circle-outline font-weight-bold ml-auto px-1 py-1 text-muted mdi-24px"></i>
                                                                </template>
                                                                <template x-if="selectedConductor === item.id">
                                                                    <i class="mdi mdi-check-circle-outline font-weight-bold ml-auto px-1 py-1 text-success mdi-24px"></i>
                                                                </template>
                                                            </div>
                                                        </template>
                                                    </div>
                                                </template>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12 col-lg-6 col-lx-6">
                                    <div x-data class="card">
                                        <div class="card-body px-1 m-1">
                                            <h4 class="card-title mt-2">DATOS DEL VEHÍCULO</h4>
                                            <div class="add-items d-flex mt-4" wire:ignore>
                                                <input x-mask="^[a-zA-Z0-9]{6,9}$" type="text"
                                                    class="form-control todo-list-input input-event"
                                                    id="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09" name="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09"
                                                    autocomplete="off" title="Placa" placeholder=" "
                                                    pattern="^[a-zA-Z0-9]{6,9}$"
                                                    data-inputmask-regex="^[a-zA-Z0-9]{6,9}$"
                                                    data-inputmask-placeholder=" "
                                                    data-inputmask-showmaskonfocus="false"
                                                    data-inputmask-showmaskonhover="false" required=""
                                                    wire:model.defer="data.bTBZOW5WRVUrRGdVZ1JlM05EQ1lsQT09" im-insert="true">
                                                <button type="button" wire:loading.attr="disabled"
                                                    class="add btn btn-primary font-weight-bold todo-list-add-btn"
                                                    x-data="{ enabled: true }"
                                                    x-on:click="if (enabled) { enabled = false; $wire.searchVehiculoPlaca(); setTimeout(() => { enabled = true; }, 1000); }"
                                                    :disabled="!enabled">Buscar</button>
                                            </div>
                        
                                            <div class="text-center">
                                                <div class="d-flex flex-column">
    
                    
</div>
                                            </div>
                        
                                            <div x-data="{
                                                selectedVehiculo: null,
                                                vehiculos: JSON.parse(JSON.stringify([])),
                                            }">
                                                <template x-if="!vehiculos.length">
                                                    <div class="text-center">
                                                        <h6 class="mb-1 text-muted">Escribe la placa del vehículo</h6>
                                                        <button type="button" class="btn btn-outline-info"
                                                            data-toggle="modal" data-target="#addNuevoVehiculo" wire:loading.attr="disabled">
                                                            Registrar Vehículo <i class="fas fa-plus"></i>
                                                        </button>
                                                    </div>
                                                </template>
                                                <template x-if="vehiculos.length">
                                                    <div>
                                                        <template x-for="item in vehiculos" :key="item.id">
                                                            <div class="d-flex align-items-center py-1 border-bottom mt-1"
                                                                 style="cursor: pointer;"
                                                                 x-on:click="$wire.__method('WEJETUxiUG5Samhpa0loM09WSW1ONDhHZGxDNVdkR1FhVXNpNjFDZVJVYz0%3D', item.id);selectedVehiculo=item.id"
                                                                 :class="{ 'alert-success': selectedVehiculo === item.id }">
                                                                <div class="ml-3">
                                                                    <small x-text="item.placa + ' - ' + item.marca + ' - ' + item.color"></small>
                                                                </div>
                                                                <template x-if="selectedVehiculo !== item.id">
                                                                    <i class="mdi mdi-circle-outline font-weight-bold ml-auto px-1 py-1 text-muted mdi-24px"></i>
                                                                </template>
                                                                <template x-if="selectedVehiculo === item.id">
                                                                    <i class="mdi mdi-check-circle-outline font-weight-bold ml-auto px-1 py-1 text-success mdi-24px"></i>
                                                                </template>
                                                            </div>
                                                        </template>
                                                    </div>
                                                </template>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body p-0 m-1">
                            <div class="faq-section mb-1">
                                <div class="container-fluid bg-primary py-2 text-center">
                                    <h4 class="mb-0 text-white">DATOS DE LOS RUBROS</h4>
                                </div>
                            </div>

                            <div class="alert alert-warning text-center" role="alert">
                                <strong class="text-success" style="font-size: 34px;">4</strong> Ingrese el rubro.
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body boxRubrosSeleccionados p-0 m-1">
                                            <h4 class="card-title mt-3">
                                                RUBROS
                                                                                                    <small class="text-danger">Por favor seleccione primero una empresa
                                                        destino</small>
                                                                                            </h4>
                                            <div class="row mt-4">
                                                <div class="col-12 col-md-8 col-lg-9 col-lx-9">
                                                    <div class="form-group">
                                                        <select wire:model.defer="data.WHlvWDNuaFpuQ2lpN1lLOXV4OVgxUT09"
                                                            id="data.WHlvWDNuaFpuQ2lpN1lLOXV4OVgxUT09"
                                                            name="data.WHlvWDNuaFpuQ2lpN1lLOXV4OVgxUT09"
                                                            class="form-control select2 select2-events lazy"
                                                             disabled="disabled"                                                             style="width: 100%;">
                                                            <option></option>
                                                                                                                    </select>
                                                        <div class="d-flex flex-column">
    
                    
</div>
                                                    </div>
                                                </div>
                                                                                                    <div class="col-12 col-md-4 col-lg-3 col-xl-3">
                                                        <button type="button"
                                                            class="btn btn-primary btn-block btn-lg font-weight-medium auth-form-btn font-weight-bold"
                                                            wire:click="__method('d2F0NU5NSWl6UzZDRlJRUmtlUlJRZz09')"
                                                             disabled="true" >
                                                            Agregar
                                                        </button>
                                                    </div>
                                                                                            </div>
                                            <style>
                                                .table th,
                                                .jsgrid .jsgrid-table th,
                                                .table td,
                                                .jsgrid .jsgrid-table td {
                                                    white-space: inherit !important;
                                                }

                                                .table td,
                                                .jsgrid .jsgrid-table td {
                                                    padding: 0.4rem 0.4rem !important;
                                                }
                                            </style>

                                                                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card">
                        <div class="card-body p-0 m-1">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group mt-1">
                                        <label class="" for="data.SklYOFdOY082VFRjamE0TFJuNC9YZz09">OBSERVACIÓN</label>
                                        <textarea type="text" wire:model.defer="data.SklYOFdOY082VFRjamE0TFJuNC9YZz09" id="data.SklYOFdOY082VFRjamE0TFJuNC9YZz09"
                                            name="data.SklYOFdOY082VFRjamE0TFJuNC9YZz09" class="form-control input-event" placeholder="OBSERVACIONES"
                                            pattern="^[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ_\s',.&]{3-270}$"
                                            data-inputmask-regex="^[a-zA-Z0-9áéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ_\s',.&]{3,270}$" data-inputmask-placeholder=" "
                                            data-inputmask-showmaskonfocus="false" data-inputmask-showmaskonhover="false" required="" rows="4"></textarea>
                                        <div class="d-flex flex-column">
    
                    
</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button wire:loading.attr="disabled"
                        class="btn btn-primary btn-lg font-weight-medium auth-form-btn pull-right mt-3" type="submit"
                        wire:click="__method('VWJlN2pYWHJkYm4wdXd0RVA3OGZlZz09')">Avanzar</button>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Livewire Component wire-end:sHMG2QtFIfB6w2F4jVnH -->
                                    </div>

                <footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Sunagro © 2025
            <a href="#" target="_blank">Superintendencia Nacional de Gestión Agroalimentaría
                <strong>Sunagro</strong></a>. Todos los derechos reservados.</span>
    </div>
</footer>
            </div>
        </div>
    </div>


    <div wire:id="4al8S7FFzlu0S65RaWfD" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;4al8S7FFzlu0S65RaWfD&quot;,&quot;name&quot;:&quot;eyJpdiI6Im9BOG1LZmM2eVVObVlIeGU3L3RlaEE9PSIsInZhbHVlIjoiQXJka3NHejYxd2xhSzBXcE8vTVdocHNiSXgwbkRvTlFwTGlscHhWYTg3QT0iLCJtYWMiOiJiMWZkNGMyMWVkYjE1OTlkNjMxYWU5ZTYwYjcyM2NhNTAxMWZkYTAxMDY3Mzk4MGM4ODJkMzg3M2FiYWQyMzMyIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;TUd1MlczY3I1UnB0Slg0bXhGVHVBOWpOajkzU0tkNmpYWG5pa0srdWRTWT0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;a0b9eabb&quot;,&quot;data&quot;:[],&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;26ff4eb13b370f64a9de6872c1c7bceb395dfca6ba2b457d525cd9049cc32779&quot;}}" wire:poll.keep-alive.50000ms="actualizarSesion">
    
</div>

<!-- Livewire Component wire-end:4al8S7FFzlu0S65RaWfD -->
    <div wire:id="oHfmJ8YbXlVhrrlVjoyK" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;oHfmJ8YbXlVhrrlVjoyK&quot;,&quot;name&quot;:&quot;eyJpdiI6Ikp6d0UvbC8wWHNTeFZpckpFQjQ4YkE9PSIsInZhbHVlIjoianVuMWFHTHBkU3lMWWpGZGJ6NUtpUT09IiwibWFjIjoiZjAyMWZjYmRiN2VhYzAxMzRhZGQ3ODc1NTBiZWU5ZTIyOWYyYTliMWM5NzU2YzMzOTUyY2I4NTAyZjllNDc0MyIsInRhZyI6IiJ9&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;bWtYK3ZwaUxOZVd1akQ2R1N3L0JYYzM3Z0JEZlpYWStDSEw3YVE1Y2JNND0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;d2fd49bb&quot;,&quot;data&quot;:[],&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;0a4b0d07a1e90d8e50ad2210f3589373116e0aa8758b11e4aae4b56bacd90498&quot;}}">
            <div class="modal fade" id="modal_expirar_session" tabindex="-1" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <img src="https://sica.sunagro.gob.ve/img/api.svg" class="mb-2" style="width: 100%;" alt="cierre_sesion">
                <h2 id="expirar_sesion_contador">
                    30<small>seg</small>
                </h2>
                <p class="mt-1 px-1 modal-body-text">
                    Su sesión se cerrará por inactividad <strong class="text-black">¿Deseas extenderla?</strong>
                </p>
            </div>
            <div class="modal-footer align-self-center ">
                <button wire:click="__method('bWtYK3ZwaUxOZVd1akQ2R1N3L0JYYzM3Z0JEZlpYWStDSEw3YVE1Y2JNND0%3D')" type="button"
                    class="btn btn-outline-primary btn-cerrar-sesion">
                    No, cerrar
                </button>
                <button id="extender_sesion" type="button" data-dismiss="modal"
                    class="btn btn-primary btn-cerrar-sesion">
                    Si, extender
                </button>
            </div>
        </div>
    </div>
</div>

        <script>
            document.addEventListener('livewire:load', function () {
                $(document).ready(function () {
                    let expirar_sesion, expirar_sesion_contador;

                    const sesion = () => {
                        expirar_sesion = setTimeout(function () {
                            $("#modal_expirar_session").modal({ backdrop: 'static', keyboard: false });
                            $("#modal_expirar_session").modal('show');
                            let contador = 45;
                            $("#expirar_sesion_contador").html(contador + '<small>seg</small>');
                            expirar_sesion_contador = setInterval(function () {
                                contador = contador - 1;
                                if (contador < 1) {
                                    $("#expirar_sesion_contador").html('¡Gracias por utilizar nuestros servicios!');
                                    setTimeout(function () {
                                        window.livewire.emit("bWtYK3ZwaUxOZVd1akQ2R1N3L0JYYzM3Z0JEZlpYWStDSEw3YVE1Y2JNND0%3D", "bWtYK3ZwaUxOZVd1akQ2R1N3L0JYYzM3Z0JEZlpYWStDSEw3YVE1Y2JNND0%3D");

                                        clearTimeout(expirar_sesion);
                                        clearInterval(expirar_sesion_contador);
                                    }, 1000 * 3);
                                } else {
                                    $("#expirar_sesion_contador").html(contador + '<small>seg</small>');
                                }
                            }, 1000);
                        }, 60000 * 60);
                    }
                    sesion();


                    $("#extender_sesion").on("click", function () {
                        clearTimeout(expirar_sesion);
                        clearInterval(expirar_sesion_contador);
                        sesion();
                    });


                    Livewire.on('OXFXR1ptSWFHTUkvZUJlMFlVeFN3aEo2YTVXOVZUbDRhaU1aLzhEdFJ5WT0%3D', function () {
                        clearTimeout(expirar_sesion);
                        clearInterval(expirar_sesion_contador);
                        sesion();
                    });
                });
            });
        </script>
        
    </div>

<!-- Livewire Component wire-end:oHfmJ8YbXlVhrrlVjoyK -->
    <div wire:id="CHFC8eDR8ud3SF1BtHzZ" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;CHFC8eDR8ud3SF1BtHzZ&quot;,&quot;name&quot;:&quot;eyJpdiI6InVsYzlDT3VXU0VrOFczQUhKN0FTSXc9PSIsInZhbHVlIjoiVXk1aDVnV1BNb3ZxOW41eHRONTUyQT09IiwibWFjIjoiYTYxNDlhOTJjZjhhYzM0YTY4MzYxNWVhYWNjNTlmMWRlOTVmZjY3ZDZjOWYzMGYzZDEzMzZiMDZjYjI0NjAxNCIsInRhZyI6IiJ9&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;a1EybVZVbVdpVlNHeUlmdWgrMHZkUi9UeTIrUW5yeGJicUpXb0xuVG5BWT0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;fd3745f0&quot;,&quot;data&quot;:[],&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;d3895e3ccadcb3ff2dccd91cb1d48f947aa2a79720ff454112a40130d92053c7&quot;}}">
    <style>
        .cambio_color {
            background-image: linear-gradient(0deg,#2c2e3e,transparent,#2c2e3e);
            background-size: 100% 900%;
        }

        .bg-pan-bottom {
            -webkit-animation: bg-pan-bottom 3s infinite;
                    animation: bg-pan-bottom 3s infinite;
        }

        @-webkit-keyframes bg-pan-bottom {
            0% {
                background-position: 50% 0%;
            }
            100% {
                background-position: 50% 100%;
            }
        }
        @keyframes bg-pan-bottom {
            0% {
                background-position: 50% 0%;
            }
            100% {
                background-position: 50% 100%;
            }
        }

        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .loader {
            background: transparent;
            border: 5px solid transparent;
            border-top: 5px outset #ffaf2a;
            border-radius: 50%;
            width: 170px;
            height: 170px;
            animation: spin 1s linear infinite;
        }

        .loading2 {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            position: absolute;
        }

        .loader2 {
            background: transparent;
            border: 5px solid transparent;
            border-right: 5px outset #0072b6;
            border-radius: 50%;
            width: 185px;
            height: 185px;
            animation: spin 1.5s linear infinite;
        }

        .loading3 {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            position: absolute;
        }

        .loader3 {
            background: transparent;
            border: 5px solid transparent;
            border-bottom: 5px outset #d30000;
            border-radius: 50%;
            width: 195px;
            height: 195px;
            animation: spin 1.9s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>

    <div class="modal" id="loadinModalCargaPesada" tabindex="-1" aria-hidden="false" wire:ignore>
        <div class="modal-dialog modal-lg" wire:ignore.self>
            <div class="modal-content fade show bg-transparent border-0" style="height: 65vh;">
                <div class="modal-body d-flex justify-content-center align-items-center">
                    <div class="loading">
                        <div class="loader"></div>
                    </div>
                    <div class="loading2">
                        <div class="loader2"></div>
                    </div>
                    <div class="loading3">
                        <div class="loader3"></div>
                    </div>

                    <center style="width: 160px;height: 159.5px;
                        padding: 32px 32px;
                        border-radius: 50%;position: absolute;" class="cambio_color bg-pan-bottom">
                        <div class="">
                            <img src="https://sica.sunagro.gob.ve/img/sunagro-logo2.png" alt="" style="width: 100%">
                        </div>
                    </center>
                </div>
            </div>
        </div>
    </div>


            <div class="modal" id="modalCSRF" tabindex="-1" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="false">
            <div class="modal-dialog">
                <div class="modal-content mt-4">
                    <div class="modal-body text-center">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <br>
                        <br>
                        <p class="mt-1 px-1 modal-body-text" id="modalCSRFText">
                            <strong class="text-black"></strong>
                        </p>
                        <br>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- Livewire Component wire-end:CHFC8eDR8ud3SF1BtHzZ -->
    <div wire:id="ITrhtIOvJFvApBUlICa3" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;ITrhtIOvJFvApBUlICa3&quot;,&quot;name&quot;:&quot;eyJpdiI6Im1pZU10SkxVZFJZTlRGZU9OVmZXK3c9PSIsInZhbHVlIjoiVVRYZ1hSU1FSY3doME1ML3BpN2lPeWZqMmVnaXoycXZTS2hDUDJnV212UT0iLCJtYWMiOiJlMGQ4YWVjNDM3NWQ2ODNjNzVhY2RkYWQ2MTRhNTJmMzUzZWFjZDQ1YjM4YWY0NWE0MTY3MzMzZWVmZTdhOWQ0IiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;eDVxak5Lam1ROHZEVng3YTR1bzF1UT09&quot;,&quot;L2w3aTl6TklVL0lWd0M3WkpDV3ZiZGpOajkzU0tkNmpYWG5pa0srdWRTWT0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;4b11ef1f&quot;,&quot;data&quot;:{&quot;data&quot;:{&quot;bTQySnJRU29HK2FIcUthL1Z6R1ZBdz09&quot;:&quot;&quot;,&quot;ZTcwK0ZmS0VxODVMOFlRZFVTalJ2Zz09&quot;:&quot;&quot;,&quot;ZDhjQlBTTmZuQ2N6ZngxQy9QSm03QT09&quot;:&quot;&quot;}},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;a78fda3123ee5bd8f977bb46540831bc1da9e0952ac3efa3d8c44c6105338338&quot;}}">
    <div class="modal" id="modal2Af" tabindex="-1" aria-hidden="false" wire:ignore.self>
        <div class="modal-dialog " wire:ignore.self>
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Autenticación de dos factores</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                </div>
                <div class="modal-body ">
                    <b>Ingrese el pin de la aplicación Google Authenticator:</b><br /><br />
                                    </div>
            </div>
        </div>
    </div>

    <script type="module">
        document.addEventListener('livewire:load', function() {
            Livewire.on("TEtNTk9EeUhzN0UvY2xZMEluZkowZz09", function(data) {
                $("#modal2Af").modal("show");
            });
            Livewire.on("NGRtb1gxZ09KVmIyWUNUbCtWdFBWQT09", function(data) {
                $("#modal2Af").modal("hide");
            });
        });
    </script>
</div>

<!-- Livewire Component wire-end:ITrhtIOvJFvApBUlICa3 -->
    <div wire:id="I4eTZKgldABnb1eFPocC" wire:initial-data="{&quot;fingerprint&quot;:{&quot;id&quot;:&quot;I4eTZKgldABnb1eFPocC&quot;,&quot;name&quot;:&quot;eyJpdiI6IkNIOFN2dEcvTEVyWHdOQmFTYnBsWkE9PSIsInZhbHVlIjoicXdSUEo3dVA1R0tGMzdGR1l0TXdHd2wzM3JlME14TEZBdDc5WGxxZEFXMD0iLCJtYWMiOiI1ODFkYjM4YzhhNzU0MWZkODcxYjQwZjgxYmIwYjg3NDZhYTA2ZmQ4MmU3ZjE4YWI2ZGI0NWY0YTNjNTAyYjMzIiwidGFnIjoiIn0=&quot;,&quot;locale&quot;:&quot;es&quot;,&quot;path&quot;:&quot;despachos\/registrar&quot;,&quot;method&quot;:&quot;GET&quot;,&quot;v&quot;:&quot;acj&quot;},&quot;effects&quot;:{&quot;listeners&quot;:[&quot;U2xUcEsrQ0dIWVk0YXB2TkE0NC9udz09&quot;,&quot;S3pCMU5QelA1N2hJeFo4R2FPajhhUT09&quot;,&quot;R0FzUEthbHkxbU1HVTdXSzNMV0ZEMGgvNkpkdlB1eEhQMmFzZGRaSG9uZz0%3D&quot;]},&quot;serverMemo&quot;:{&quot;children&quot;:[],&quot;errors&quot;:[],&quot;htmlHash&quot;:&quot;471a4e65&quot;,&quot;data&quot;:{&quot;componente&quot;:false,&quot;data&quot;:false},&quot;dataMeta&quot;:[],&quot;checksum&quot;:&quot;8de778c667305e097239b1d853e961b9289f6ce1d52f5c4e439baaff3ebdcfbf&quot;}}">
    <div class="modal" id="modalGlobalPantalla-000" tabindex="-1" aria-hidden="false" wire:ignore.self>
        <div class="modal-dialog modal-lg" wire:ignore.self>
                    </div>
    </div>
</div>


<!-- Livewire Component wire-end:I4eTZKgldABnb1eFPocC -->
    <div class="loading-top">
    <div class="d-lg-flex align-items-center justify-content-center" style="width: 50px;">
        <img class="log rotate-1-cw" src="https://sica.sunagro.gob.ve/img/sunagro_icon_1.png" alt="Sunagro Logo" />
        <img class="log rotate-2-cw" src="https://sica.sunagro.gob.ve/img/sunagro_icon_2.png" alt="Sunagro Logo" />
    </div>
</div>


    <script src="https://sica.sunagro.gob.ve/js/sunagro-js.min.js?v=1.0.4" type="text/javascript"></script>
    <script src="https://sica.sunagro.gob.ve/js/app.js?v=1.0.4"></script>

    <div class="modal fade" id="modal_tutoriales" tabindex="-1" aria-labelledby="exampleModalCenterTitle"
    aria-hidden="false" style="margin-top: -50px;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>

                <img src="https://sica.sunagro.gob.ve/img/api.svg" class="mb-2" style="width: 100%;" alt="cierre_sesion">
                <br>
                <p class="mt-1 px-1 modal-body-text">
                    Estimado usuario, le invitamos a consultar los tutoriales sobre los diferentes procesos del sistema <strong>SICA</strong> en el siguiente enlace.<br>

                    <a href="https://www.youtube.com/@sunagrooficial9064" target="_blank">Tutoriales</a>
                </p>
                <br>
            </div>
        </div>
    </div>
</div>
    
    <script type="text/javascript">
        $(document).ready(function($) {
            $('.nav-link.active').each(function() {
                let aux = $(this).closest('.nav');
                aux = aux.closest('.nav-item');
                aux.children('.nav-link').addClass('active');
            });

                        
            
            
            
            
                    });
    </script>
    <script type="module">
        import {
            global
        } from"/js/sunagro-modules-js.js?v=1.0.4"
        global.showContent();
        global.events();
    </script>
            <script type="module">
        const select2General = () => {
            $('.componentRegistro .boxRubrosSeleccionados .select2').select2({
                placeholder: "SELECCIONAR",
            });
            $('.componentRegistro .boxPuerto .select2').select2({
                placeholder: "SELECCIONAR",
            });
            $('.componentRegistro .boxCuspal .select2').select2({
                placeholder: "SELECCIONAR",
            });
        }

        document.addEventListener('livewire:load', function() {
            const addInputmask = (div) => {
                $(div).find('.input-event').each(function() {
                    $(this).inputmask();
                    $(this).change((e) => {
                        window.livewire.find('sHMG2QtFIfB6w2F4jVnH').set(e.target.name, e.target.value, !$(e.target).hasClass('lazy'));
                    });
                });
            }

            $('.componentRegistro').on('change', '.select2-events, .allcheck ', function() {
                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').set($(this).attr('name'), $(this).val(), true);
            });

            $('.componentRegistro').on('click', '.onEmitEmpresaCodigo', function() {
                let data = $(this).attr('data');

                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').emit("LzN6OGVJbzFJNjBlSW5PRk9XOWVaQkMzNVZ0bGVrWmVzc3FlTmVnQzloVT0%3D", "LzN6OGVJbzFJNjBlSW5PRk9XOWVaQkMzNVZ0bGVrWmVzc3FlTmVnQzloVT0%3D",
                    data, true);
            });

            $('.componentRegistro').on('click', '.onEmitConductorCedula', function() {
                let data = $(this).attr('data');

                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').emit("YTJnWEJUbmZ4UVR1NWtydHdXZWtGM1hxVGIwQ2xlTXVzNTlZcllCL0xVYz0%3D",
                    "YTJnWEJUbmZ4UVR1NWtydHdXZWtGM1hxVGIwQ2xlTXVzNTlZcllCL0xVYz0%3D", data, true);
            });

            $('.componentRegistro').on('click', '.onEmitVehiculoPlaca', function() {
                let data = $(this).attr('data');

                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').emit("WEJETUxiUG5Samhpa0loM09WSW1ONDhHZGxDNVdkR1FhVXNpNjFDZVJVYz0%3D", "WEJETUxiUG5Samhpa0loM09WSW1ONDhHZGxDNVdkR1FhVXNpNjFDZVJVYz0%3D",
                    data, true);
            });

            addInputmask(".componentRegistro");
            $('.componentRegistro').on('keyup', '.inputCapacidadFormato', function() {
                let num = formatoTonelada(this);
                $(this).attr('title', num + " = KG " + convertirToneladasAKilos(num));
                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').set($(this).attr('id'), num, true);
            });

            $('.componentRegistro').on('keyup', '.inputMontoFormato', function() {
                window.livewire.find('sHMG2QtFIfB6w2F4jVnH').set($(this).attr('id'), formatoMonto(this), true);
            });

            select2General();
            Livewire.hook('message.processed', (message, component) => {
                select2General();
            });
            Livewire.on("NUZuZDJWY01MZjU1VmlKRVhraUJ1Q1Y1d3dhemN2QXRUdTJDRlVRa0JyYz0%3D", function() {
                select2General();
                addInputmask(".boxRubrosSeleccionados");
            });

            function formatCurrencyTonelada(total) {
                var neg = false;
                if (total < 0) {
                    neg = true;
                    total = Math.abs(total);
                }
                return parseFloat(total, 10).toFixed(3).replace(/(\d)(?=(\d{3})+\.)/g, "$1,");
            }

            const formatoTonelada = (e) => {
                let cad = e.value;
                let pattern = /[^0-9]/g;
                cad = cad.replace(pattern, ''); /*remplazo todo lo que no sea numerico*/

                while (cad.length < 4) {
                    cad = "0" + cad; //agrego 0 al inicio necesarios si el valor tiene menos de cuatro numeros
                }

                let primer_numero = cad.slice(0,
                    1); //para eliminar el primer numero si es un 0, y tienen mas de 4 numeros
                let entero = (primer_numero == 0 && cad.length > 4) ? cad.slice(1, -3) : cad.slice(0, -
                    3); /*obtiene parte entera del numero, */
                let decimal = cad.slice(-3); /*obtiene los tres ultimos numeros, para la parte decimal*/
                let monto_completo = entero + "." + decimal; /*recontruyo el monto decimal */
                let aux = formatCurrencyTonelada(monto_completo); /*asigno el valor al campo*/
                aux = aux + '';
                aux = aux.replace(/\./g, 'x');
                aux = aux.replace(/,/g, '.');
                aux = aux.replace(/x/g, ',');

                e.value = aux + '';
                return e.value + '';
            }

            function convertirToneladasAKilos(toneladas) {
                let pattern = /[^0-9,]/g;
                let valorNumerico = toneladas.replace(pattern, '');
                valorNumerico = valorNumerico.replace(/,/g, '.');
                valorNumerico = parseFloat(valorNumerico);
                let kilogramos = valorNumerico * 1000;
                let monto = kilogramos.toLocaleString('en-US');
                monto = monto + '';
                monto = monto.replace(/\./g, 'x');
                monto = monto.replace(/,/g, '.');
                monto = monto.replace(/x/g, ',');
                return monto;
            }

            function formatCurrencyMonto(total) {
                var neg = false;
                if (total < 0) {
                    neg = true;
                    total = Math.abs(total);
                }
                return parseFloat(total, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,").toString();
            }

            const formatoMonto = (e) => {
                let cad = e.value;
                let pattern = /[^0-9]/g;
                cad = cad.replace(pattern, ''); /*remplazo todo lo que no sea numerico*/

                while (cad.length < 3) {
                    cad = "0" + cad; //agrego 0 al inicio necesarios si el valor tiene menos de tres numeros
                }

                let primer_numero = cad.slice(0,
                    1); //para eliminar el primer numero si es un 0, y tienen mas de 3 numeros
                let entero = (primer_numero == 0 && cad.length > 3) ? cad.slice(1, -2) : cad.slice(0, -
                    2); /*obtiene parte entera del numero, */
                let decimal = cad.slice(-2); /*obtiene los dos ultimos numeros, para la parte decimal*/
                let monto_completo = entero + "." + decimal; /*recontruyo el monto decimal */
                let aux = formatCurrencyMonto(monto_completo); /*asigno el valor al campo*/
                aux = aux + '';
                aux = aux.replace(/\./g, 'x');
                aux = aux.replace(/,/g, '.');
                aux = aux.replace(/x/g, ',');

                e.value = aux + '';
                return aux + '';
            }
        });
    </script>
    <script type="module">
        import { global } from"/js/sunagro-modules-js.js?v=1.0.4"

        document.addEventListener('livewire:load', function() {
            const addInputmask = (div) => {
                $(div).find('input').each(function() {
                    $(this).inputmask();
                    $(this).change((e) => {
                        window.livewire.find('LSqy2MOlKyUE0APoPcrj').set(e.target.id, e.target.value, !$(e.target).hasClass('lazy'));
                    });
                });
            }

            addInputmask(".componentModalAyuda");
        });
    </script>
    <script type="module">
        import { global } from"/js/sunagro-modules-js.js?v=1.0.4"
                    global.blockClick();
            global.blockTeclado();
            global.monitorearInspector("https://sica.sunagro.gob.ve/seguridad");
            global.detectorNavegador("https://sica.sunagro.gob.ve/navegador_antiguo", "https://sica.sunagro.gob.ve/navegador_no_soportado");
        
        global.asincHora();
    </script>
    <script type="module">
        window.addEventListener('beforeunload', function (event) {
            $('#loadinModalCargaPesada').modal({
                backdrop: 'static',
                keyboard: false
            });
            $('#loadinModalCargaPesada').modal('show');
        });
    </script>
             <script>
            Livewire.onError((status, response) => {
                if (window.location.protocol !== "https:") {
                    $("#modalCSRFText").html(
                        "Estás utilizando una conexión no segura (HTTP). Por favor, accede al sitio mediante HTTPS para evitar errores."
                    );
                    $("#modalCSRF").modal("show");
                    return false; // Evitar el manejo por defecto
                }

                if (status === 419) {
                    $("#modalCSRFText").html("Tu sesión se ha cerrado. Serás redirigido a la página de inicio de sesión en 5 segundos.");
                    $("#modalCSRF").modal("show");
                    setTimeout(() => {
                        window.location.href = "https://sica.sunagro.gob.ve/login";
                    }, 5000);
                    return false;
                }

                if (status === 403) {
                    $("#modalCSRFText").html("No tienes permiso para realizar esta acción.");
                    $("#modalCSRF").modal("show");
                    return false;
                }

                if (status === 404) {
                    $("#modalCSRFText").html("Recurso no encontrado. Por favor, verifica tu acción.");
                    $("#modalCSRF").modal("show");
                    return false;
                }

                if (status === 500) {
                    $("#modalCSRFText").html("Error interno del servidor.");
                    $("#modalCSRF").modal("show");
                    return false;
                }

                if (status === 422) {
                    $("#modalCSRFText").html("Error de validacion.");
                    $("#modalCSRF").modal("show");
                    return false;
                }

                if (status === 401) {
                    $("#modalCSRFText").html("Tu sesión ha expirado. Por favor, inicia sesión nuevamente.");
                    $("#modalCSRF").modal("show");
                    window.location.href = "https://sica.sunagro.gob.ve/login";
                    return false;
                }

                if (status === 0) {
                    $("#modalCSRFText").html("No se pudo conectar con el servidor. Verifica tu conexión a Internet.");
                    $("#modalCSRF").modal("show");
                    return false;
                }

                $("#modalCSRFText").html(`Ocurrió un error inesperado (${status}). Intenta nuevamente.`);
                $("#modalCSRF").modal("show");
                return false;
            });
        </script>
        <script>
        document.addEventListener('livewire:load', function() {
            $(document).ready(function() {
                Livewire.on("Y2xxL3BibFp4cGdGZU1aM3NWWUo1eWRLVEtCb3NtaC8xYUpVR0M5TmJzRT0%3D", function(data) {
                    $('#modalGlobalPantalla-000').modal({
                        backdrop: 'static',
                        keyboard: false
                    });
                    $('#modalGlobalPantalla-000').modal('show');
                });

                Livewire.on("QjkvbVRGQm5ydjcwRnlLRHFMMHFsQ2RLVEtCb3NtaC8xYUpVR0M5TmJzRT0%3D", function(data) {
                    $('#modalGlobalPantalla-000').modal('hide');
                });

                $('#modalGlobalPantalla-000').off('click', '.closePantalla').on('click', '.closePantalla', function() {
                    window.livewire.find('I4eTZKgldABnb1eFPocC').emit("R0FzUEthbHkxbU1HVTdXSzNMV0ZEMGgvNkpkdlB1eEhQMmFzZGRaSG9uZz0%3D", "R0FzUEthbHkxbU1HVTdXSzNMV0ZEMGgvNkpkdlB1eEhQMmFzZGRaSG9uZz0%3D");
                });
            });
        });
    </script>
    <script>
        document.addEventListener('livewire:load', function () {
            let counter_ = 0;

            const loadingTop = () => {
                if(counter_ < 1){
                    $('.loading-top').fadeOut();
                    $('.buttons-events').removeAttr('disabled');
                }else{
                    $('.loading-top').fadeIn();
                    $('.buttons-events').attr('disabled', true);
                }
            }

            $(document).ready(function() {
                loadingTop();

                Livewire.hook('message.sent', (message, component) => {
                    counter_++;
                    loadingTop();
                })
                Livewire.hook('message.processed', (message, component) => {
                    counter_--;
                    loadingTop();
                })
            });
        });
    </script>
</body>

</html>


